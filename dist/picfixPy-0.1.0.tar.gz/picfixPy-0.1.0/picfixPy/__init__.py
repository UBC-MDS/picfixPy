#init picfixPy

import skimage.io
import numpy as np
